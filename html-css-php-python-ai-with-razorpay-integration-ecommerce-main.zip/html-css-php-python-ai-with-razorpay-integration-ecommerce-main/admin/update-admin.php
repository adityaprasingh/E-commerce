<?php include('../config/constants.php'); ?>

<html>

<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" >
    
    <title>Admin@Youslay | Update Admin</title>

    <!--themify icons css-->
    <link rel="stylesheet" href="../css/themify-icons.css">

    <!--bootstrap 5 css-->
    <link rel="stylesheet" href="../css/bootstrap.min.css">

    <!--responsive css-->
    <link rel="stylesheet" href="../css/responsive.css">
     <!--bootstrap JS-->
 <script src="js/bootstrap.min.js"></script>
    
</head>
<body style="background:lavenderblush">
    <header style="padding:10px; margin:5px">WORK IN PROGRESS!!</header>
<a style="padding:10px; margin:5px" href="<?php echo SITEURL; ?>admin/manage-admin.php">
          <button type="button" class="btn btn-outline-danger " >Go back

          </button>
        </a>
</body>
</html>